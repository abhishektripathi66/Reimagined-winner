WyckoffPro for Android (installable web app)

What's included
- index.html: the same WyckoffPro app, with a phone layout and large touch controls.
- manifest.webmanifest, service-worker.js, icon.svg: Android install and app-shell files.

Install on Android
1. Put this folder on a static web host that serves HTTPS. The hosting service must serve index.html, manifest.webmanifest, service-worker.js and icon.svg from the same folder.
2. Open the hosted index.html URL in Chrome on the Android phone.
3. Open Chrome's menu and choose Install app (or Add to Home screen), then launch WyckoffPro from the new icon.
4. Sign in/configure tokens on that phone. Browser local storage is device- and browser-profile-specific; tokens from desktop do not automatically transfer.

Market-data connection
The app can use its Yahoo-based free index model without an Upstox option chain. Upstox/Dhan live option-chain and broker requests go through dhan-proxy.js. The desktop setting http://127.0.0.1:8765/dhan points back to the phone itself when used on Android, so it will not reach the proxy on the PC. For live broker data, the proxy must be made available to the phone through a secure HTTPS endpoint and that endpoint entered in the app's Local proxy URL field. Do not expose the unauthenticated local proxy directly to the public internet. No proxy tunnel or public server is included in this package.

Notifications
Allow notifications in Chrome when prompted and tap Enable alerts in Options Intel. Browser notifications require HTTPS and the app must remain open for scans to continue.

Installability and offline use
The app shell can open after it has been cached, but market data, broker APIs, AI services and chart libraries need an internet connection. A static HTML file opened with file:// is not installable as a PWA; serve it from HTTPS.
